# `@theme.tools/billing`

> **Integer Minor-Unit Currency Ledger & Entitlement Engine** (application-engines · layer: `engines`)

Strict integer minor-unit arithmetic (zero IEEE-754 float drift), idempotent webhook ingestion, and append-only ledgers.

## Narrow Entry Points

- `@theme.tools/billing/contracts` — Pure TypeScript contracts, schemas, and event descriptors (zero DOM/Worker globals).
- `@theme.tools/billing/core` — Deterministic domain state machines and validation logic.
- `@theme.tools/billing/cloudflare` — Cloudflare Workers / Hono route descriptors and binding requirements (D1, Queues, DurableObjects).
- `@theme.tools/billing/react` — React 19 surface descriptors (`PricingAndEntitlementTable`).
- `@theme.tools/billing/elements` — Custom Element registration (`<tt-billing-table>`).
- `@theme.tools/billing/testing` — Deterministic conformance suite and test fixtures.
