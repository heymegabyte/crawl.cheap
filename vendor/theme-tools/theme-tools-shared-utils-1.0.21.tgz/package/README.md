# @theme-tools/shared-utils

Foundational pure Cloudflare Workers V8 and browser-safe utility contracts for the `@theme.tools` ecosystem, including interaction state tokens (`INTERACTION_STATE_TOKENS`), RFC 9651 HTTP Structured Fields, RFC 9562 monotonic UUIDv7 generation, RFC 9535 JSONPath, RFC 6570 Level 4 URI Templates, RFC 9110 HTTP negotiation/preconditions, W3C `Server-Timing`, RFC 9211 `Cache-Status`, and shared domain catalogs.
