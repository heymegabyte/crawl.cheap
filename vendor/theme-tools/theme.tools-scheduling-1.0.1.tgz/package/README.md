# `@theme.tools/scheduling`

> **IANA Timezone Availability & Concurrency-Safe Booking Engine** (application-engines · layer: `engines`)

DST-safe slot computation, buffer windows, and Durable Object atomic slot locking to prevent double bookings.

## Narrow Entry Points

- `@theme.tools/scheduling/contracts` — Pure TypeScript contracts, schemas, and event descriptors (zero DOM/Worker globals).
- `@theme.tools/scheduling/core` — Deterministic domain state machines and validation logic.
- `@theme.tools/scheduling/cloudflare` — Cloudflare Workers / Hono route descriptors and binding requirements (D1, DurableObjects, Queues).
- `@theme.tools/scheduling/react` — React 19 surface descriptors (`BookingSlotPicker`).
- `@theme.tools/scheduling/elements` — Custom Element registration (`<tt-booking-picker>`).
- `@theme.tools/scheduling/testing` — Deterministic conformance suite and test fixtures.
