# `@theme.tools/seo-geo`

> **Canonical URLs, JSON-LD Graph Synthesizer & Staging Noindex Guard** (foundational-utilities · layer: `foundations`)

Deterministic canonical URLs, Schema.org JSON-LD graph validation, GEO citation summaries, and staging noindex headers.

## Narrow Entry Points

- `@theme.tools/seo-geo/contracts` — Pure TypeScript contracts, schemas, and event descriptors (zero DOM/Worker globals).
- `@theme.tools/seo-geo/core` — Deterministic domain state machines and validation logic.
- `@theme.tools/seo-geo/cloudflare` — Cloudflare Workers / Hono route descriptors and binding requirements (KV).
- `@theme.tools/seo-geo/react` — React 19 surface descriptors (`SeoGeoReadinessCard`).
- `@theme.tools/seo-geo/elements` — Custom Element registration (`<tt-seo-readiness>`).
- `@theme.tools/seo-geo/testing` — Deterministic conformance suite and test fixtures.
